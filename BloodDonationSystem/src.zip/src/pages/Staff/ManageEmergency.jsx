const ManageEmergencyPage = () =>{
return(
    <>
    <h1>Trang quản lý yêu cầu máu khẩn cấp</h1>
    </>
)
};
export default ManageEmergencyPage;